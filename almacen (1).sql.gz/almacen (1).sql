-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 27-09-2017 a las 17:15:52
-- Versión del servidor: 10.1.25-MariaDB
-- Versión de PHP: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `almacen`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `p`
--

CREATE TABLE `p` (
  `pn` varchar(55) COLLATE utf8_spanish_ci NOT NULL,
  `pnombre` varchar(55) COLLATE utf8_spanish_ci NOT NULL,
  `color` varchar(55) COLLATE utf8_spanish_ci NOT NULL,
  `peso` int(55) NOT NULL,
  `ciudad` varchar(55) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `p`
--

INSERT INTO `p` (`pn`, `pnombre`, `color`, `peso`, `ciudad`) VALUES
('p1', 'tuerca', 'verde', 12, 'Paris'),
('p2', 'perno', 'rojo', 17, 'Londres'),
('p3', 'birlo', 'azul', 17, 'Roma'),
('p4', 'birlo', 'rojo', 14, 'Londres'),
('p5', 'leva', 'azul', 12, 'Paris'),
('p6', 'engranaje', 'rojo', 19, 'Paris');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `s`
--

CREATE TABLE `s` (
  `sn` varchar(55) COLLATE utf8_spanish_ci NOT NULL,
  `snombre` varchar(55) COLLATE utf8_spanish_ci NOT NULL,
  `estado` int(55) NOT NULL,
  `ciudad` varchar(55) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `s`
--

INSERT INTO `s` (`sn`, `snombre`, `estado`, `ciudad`) VALUES
('s1', 'Salazar', 20, 'Londres'),
('s2', 'Jaimes', 10, 'Paris'),
('s3', 'Bernal', 30, 'Paris'),
('s4', 'Corona', 20, 'Londres'),
('s5', 'Aldana', 30, 'Atena');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sp`
--

CREATE TABLE `sp` (
  `sn` varchar(55) COLLATE utf8_spanish_ci NOT NULL,
  `pn` varchar(55) COLLATE utf8_spanish_ci NOT NULL,
  `cant` int(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `sp`
--

INSERT INTO `sp` (`sn`, `pn`, `cant`) VALUES
('s1', 'p1', 300),
('s1', 'p2', 200),
('s1', 'p3', 400),
('s1', 'p4', 200),
('s1', 'p5', 100),
('s1', 'p6', 100),
('s2', 'p1', 300),
('s2', 'p2', 400),
('s3', 'p2', 200),
('s4', 'p2', 200),
('s4', 'p3', 100),
('s4', 'p4', 300),
('s4', 'p5', 400);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `p`
--
ALTER TABLE `p`
  ADD PRIMARY KEY (`pn`);

--
-- Indices de la tabla `s`
--
ALTER TABLE `s`
  ADD PRIMARY KEY (`sn`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
